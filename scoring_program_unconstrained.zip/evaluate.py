#!/usr/bin/env python
import sys
import os
import json
import traceback
import logging
from sklearn.metrics import accuracy_score, f1_score


class StreamToLogger(object):
    """
    Fake file-like stream object that redirects writes to a logger instance.
    """
    def __init__(self, logger, level):
        self.logger = logger
        self.level = level
        self.linebuf = ''

    def write(self, buf):
        for line in buf.rstrip().splitlines():
            self.logger.log(self.level, line.rstrip())

    def flush(self):
        pass


def macro_average(scores):
    return sum(scores)/len(scores)


def score_traceback(score, labels, preds, i):
    try:
        if score == f1_score:
            return score(labels, preds, average='macro')
        else:
            return score(labels, preds)
    # except ValueError as e:
    #     raise Exception('Error in the following input #%s' % i.with_traceback(e.__traceback__)
    except ValueError as e:
        sys.stdout.write('Cannot compute %s. Error in sentence #%s' % (score, i))
        traceback.print_tb(e.__traceback__)
        return 0


def accuracy_score_3(labels, preds):
    acc_score = []
    for lbl, prd in zip(labels, preds):
        if lbl in prd:
            acc_score.append(1)
        else:
            acc_score.append(0)
    return macro_average(acc_score)


def load_data(task_dir, language):
    res_file_path = os.path.join(submit_dir, task_dir, '%s.json' % language)
    print('Results: %s' % res_file_path)
    ref_file_path = os.path.join(truth_dir, task_dir, '%s.json' % language)
    print('Reference data %s\n' % ref_file_path)
    with open(res_file_path, 'r', encoding='utf-8') as f1:
        res_data = json.load(f1)
    with open(ref_file_path, 'r', encoding='utf-8') as f2:
        ref_data = json.load(f2)
    return ref_data, res_data


def compute_pos_scores(language):
    try:
        ref_data, res_data = load_data('pos_tagging', language)
        acc_all = []
        f1_all = []
        for ref_sent, res_sent in zip(ref_data, res_data):
            ref = [tok[1] for tok in ref_sent]
            res = [tok[1] for tok in res_sent]
            sent_acc = score_traceback(accuracy_score, ref, res, res_data.index(res_sent))
            sent_f1 = score_traceback(f1_score, ref, res, res_data.index(res_sent))
            acc_all.append(sent_acc)
            f1_all.append(sent_f1)
        pos_accuracy = macro_average(acc_all)
        pos_f1 = macro_average(f1_all)
    except FileNotFoundError:
        print('POS-tagging results for %s not found' % language)
        pos_accuracy = 0
        pos_f1 = 0
    return pos_accuracy, pos_f1


def compute_lemma_scores(language):
    try:
        ref_data, res_data = load_data('lemmatisation', language)
        acc1_all = []
        acc3_all = []
        for ref_sent, res_sent in zip(ref_data, res_data):
            ref = [tok[1] for tok in ref_sent]
            res3 = [tok[1] for tok in res_sent]
            res1 = [tok[0] for tok in res3]
            sent_acc1 = score_traceback(accuracy_score, ref, res1, res_data.index(res_sent))
            sent_acc3 = score_traceback(accuracy_score_3, ref, res3, res_data.index(res_sent))
            acc1_all.append(sent_acc1)
            acc3_all.append(sent_acc3)
        lemma_accuracy_1 = macro_average(acc1_all)
        lemma_accuracy_3 = macro_average(acc3_all)
    except FileNotFoundError:
        print('Lemmatisation results for %s not found' % language)
        lemma_accuracy_1 = 0
        lemma_accuracy_3 = 0
    return lemma_accuracy_1, lemma_accuracy_3


def compute_morph_scores(language):
    try:
        ref_data, res_data = load_data('morph_features', language)
        acc_all = []
        for ref_sent, res_sent in zip(ref_data, res_data):
            sent_acc = []
            for ref_token, res_token in zip(ref_sent, res_sent):
                if ref_token['Token'] == res_token['Token']:
                    if len(ref_token) > 2:
                        ref_token.pop('Token')
                        res_token.pop('Token')
                        # we ask you to submit UPOS as well as features for readability and cross-checking
                        # but the score is only based on morphological feature predictions
                        ref_token.pop('UPOS')
                        res_token.pop('UPOS')
                        token_acc = []
                        # reward for correctly predicting features
                        for k, v in ref_token.items():
                            if k in res_token.keys() and res_token[k] == v:
                                token_acc.append(1)
                            else:
                                token_acc.append(0)
                        # punishment for predicting non-existing features
                        for k in res_token.keys():
                            if k not in ref_token.keys():
                                token_acc.append(-1)
                        sent_acc.append(macro_average(token_acc))
                    else:
                        sent_acc.append(1)
                else:
                    sent_acc.append(0)
            acc_all.append(macro_average(sent_acc))
        final_acc = macro_average(acc_all)
    except FileNotFoundError:
        print('Morphological analysis results for %s not found' % language)
        final_acc = 0
    return final_acc


def compute_mask_scores(language, mode='char'):
    try:
        ref_data, res_data = load_data('fill_mask_%s' % mode, language)
        acc1_all = []
        acc3_all = []
        for ref_sent, res_sent in zip(ref_data, res_data):
            ref = ref_sent['masked_tokens']
            if len(ref) > 0:
                res3 = res_sent['masked_tokens']
                res1 = [mask[0] for mask in res3]
                sent_acc1 = score_traceback(accuracy_score, ref, res1, res_data.index(res_sent))
                sent_acc3 = score_traceback(accuracy_score_3, ref, res3, res_data.index(res_sent))
                acc1_all.append(sent_acc1)
                acc3_all.append(sent_acc3)
        mask_accuracy_1 = macro_average(acc1_all)
        mask_accuracy_3 = macro_average(acc3_all)
    except FileNotFoundError:
        print('Filling the gaps (%s-level) results for %s not found' % (mode, language))
        mask_accuracy_1 = 0
        mask_accuracy_3 = 0
    return mask_accuracy_1, mask_accuracy_3


if __name__ == '__main__':

    langs = ['chu', 'cop', 'fro', 'got', 'grc', 'hbo', 'isl', 'lat', 'latm', 'lzh', 'ohu', 'orv', 'san', 'sga', 'mga', 'ghc']

    input_dir = sys.argv[1]
    output_dir = sys.argv[2]

    submit_dir = os.path.join(input_dir, 'res')
    truth_dir = os.path.join(input_dir, 'ref')

    sys.stdout.write('Input dir: %s' % input_dir)
    sys.stdout.write(str(os.listdir(input_dir)))
    sys.stdout.write('Submission dir: %s' % submit_dir)
    sys.stdout.write(str(os.listdir(submit_dir)))
    sys.stdout.write('Reference dir: %s' % truth_dir)
    sys.stdout.write(str(os.listdir(truth_dir)))

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s: %(levelname)s: %(name)s: %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(output_dir, 'evaluation.log')),
            logging.StreamHandler()]
    )

    logger = logging.getLogger(__name__)

    sys.stdout = StreamToLogger(logger, logging.INFO)
    sys.stderr = StreamToLogger(logger, logging.ERROR)

    if not os.path.isdir(submit_dir):
        print('%s doesn\'t exist, submission invalid' % submit_dir)
    else:
        with open(os.path.join(output_dir, 'scores.txt'), 'w', encoding='utf-8') as f:
            for lang in langs:
                print("\n\nCOMPUTING SCORES FOR %s..." % lang.upper())
                # Compute scores from submitted results
                lang_scores = []
                if lang not in ['sga', 'mga', 'ghc']:
                    print('POS-tagging')
                    pos_score = macro_average(compute_pos_scores(lang))
                    print('Lemmatisation')
                    lemma_score = macro_average(compute_lemma_scores(lang))
                    print('Detailed morphological analysis')
                    morph_score = compute_morph_scores(lang)
                    lang_scores.append(pos_score)
                    lang_scores.append(lemma_score)
                    lang_scores.append(morph_score)
                    f.write('%s_pos: %s\n' % (lang, pos_score))
                    f.write('%s_lemma: %s\n' % (lang, lemma_score))
                    f.write('%s_full_morph: %s\n' % (lang, morph_score))
                print('Filling the gaps (character-level)')
                char_mask_score = macro_average(compute_mask_scores(lang, mode='char'))
                print('Filling the gaps (word-level)')
                word_mask_score = macro_average(compute_mask_scores(lang, mode='word'))
                lang_scores.append(char_mask_score)
                lang_scores.append(word_mask_score)
                lang_avg_score = macro_average(lang_scores)
                f.write('%s_fill_mask_char: %s\n' % (lang, char_mask_score))
                f.write('%s_fill_mask_word: %s\n' % (lang, word_mask_score))
                f.write('%s_avg_score: %s\n' % (lang, lang_avg_score))
